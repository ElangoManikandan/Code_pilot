<?php
/**
 * The header for our theme
 *
 * @package Sensei S2
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) { 
  exit; // Exit if accessed directly. 
}

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset');?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
  if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
  }
?><a href="#main-content" class="skip-link screen-reader-text"><?php esc_html_e( 'Skip to content', 'sensei-s2' ); ?></a>
<header id="header" role="banner">
  <div class="header">
    <div class="content" <?php if ( is_user_logged_in() ) : echo 'style="padding-top: 32px;"'; endif; ?>>
      <nav role="navigation" aria-label="main-navigation">
        <?php $custom_logo_id = get_theme_mod( 'custom_logo' ); ?>
        <?php $logo = wp_get_attachment_image_src( $custom_logo_id , 'large' ); ?>
        <?php if ( has_custom_logo() ) : ?>
        <a href="<?php echo esc_url(home_url()); ?>" title="<?php bloginfo('name'); ?>" class="brand" tabindex="0">
          <img src="<?php echo esc_url( $logo[0] ); ?>" alt="<?php bloginfo('name'); ?>">
        </a>
        <?php else : ?>
        <span class="brand"></span>
        <?php endif; ?>
        <?php if ( has_nav_menu( 'main-menu' ) ) : ?>
          <div class="menu">
            <button class="navbar" aria-label="Toggle navigation menu" tabindex="0">
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>

            <?php wp_nav_menu(array(
              'menu' => 'main-menu',
              'theme_location' => 'main-menu',
              'menu_class' => 'nav',
              'container' => false,
              'menu_id' => false,
              'depth' => 2,
            ));
            ?>
          </div> <!-- menu -->
        <?php endif ?>
      </nav>
    </div> <!-- content -->
  </div> <!-- header -->
</header>
