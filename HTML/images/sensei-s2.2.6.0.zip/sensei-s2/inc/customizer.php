<?php
/**
 * Contains methods for customizing the theme customization screen.
 *
 * @link https://codex.wordpress.org/Theme_Customization_API
 *
 * @package Sensei S2
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) { 
  exit; // Exit if accessed directly. 
}

/** Customizer settings */

/** Add custom logo */
function senseis2_custom_logo_setup() {
  $defaults = array(
  );
  add_theme_support( 'custom-logo', $defaults );
}
add_action( 'after_setup_theme', 'senseis2_custom_logo_setup' );

/** Remove background image customize */
function senseis2_theme_customize_register( $wp_customize ) {
	$wp_customize->remove_section("background_image");
  $wp_customize->remove_section("colors");

    /** Call to action */
    $wp_customize -> add_section( 'senseis2__home__cta',
    array(
    'title' => esc_html__( 'Call To Action', 'sensei-s2' ),
    'priority' => 80,
    )
  );

  $wp_customize -> add_setting( 'senseis2__home__cta__title',
    array(
    'default' => esc_html__( 'Call To Action', 'sensei-s2' ),
    'sanitize_callback' => 'sanitize_text_field'
    )
  );

  $wp_customize -> add_control( 'senseis2__home__cta__title',
    array(
    'label' => esc_html__( 'Button text', 'sensei-s2' ),
    'section' => 'senseis2__home__cta',
    'type' => 'text',
    )
  );

  $wp_customize -> add_setting( 'senseis2__home__cta__link',
    array(
    'default' => esc_html__( '#', 'sensei-s2' ),
    'sanitize_callback' => 'sanitize_text_field'
    )
  );

  $wp_customize -> add_control( 'senseis2__home__cta__link',
    array(
    'label' => esc_html__( 'Link text', 'sensei-s2' ),
    'section' => 'senseis2__home__cta',
    'type' => 'text',
    )
  );

  /** Add customizer section color */
  $wp_customize->add_section( 'senseis2_color_section', array(
    'title' => 'Sensei S2 Colors',
    'priority' => '90'                  
  ));

  $wp_customize->add_setting( 'senseis2_theme_primary', array(
    'default' => '#39f',
    'sanitize_callback' => 'sanitize_text_field'
  ));

  $wp_customize->add_setting( 'senseis2_theme_secondary', array(
    'default' => '#45de27',  
    'sanitize_callback' => 'sanitize_text_field'                      
  ));

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'senseis2_theme_primary', array(
    'label' => 'Primary',
    'section' => 'senseis2_color_section',
    'settings' => 'senseis2_theme_primary'
  )));

  $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'senseis2_theme_secondary', array(
    'label' => 'Secondary',
    'section' => 'senseis2_color_section',
    'settings' => 'senseis2_theme_secondary'
  )));
}
add_action( 'customize_register', 'senseis2_theme_customize_register' );

function senseis2_generate_theme_option_css() {
  $primary = get_theme_mod('senseis2_theme_primary');
  $secondary = get_theme_mod('senseis2_theme_secondary');

  if(!empty($primary)) :
  ?>
  <style id="senseis2-theme-option-css">
      :root {
      --primary: <?php echo $primary; ?>;
      --secondary: <?php echo $secondary; ?>;
      }
  </style>    
  <?php endif;    
}
add_action( 'wp_head', 'senseis2_generate_theme_option_css' );
