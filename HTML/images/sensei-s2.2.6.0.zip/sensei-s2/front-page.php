<?php
/**
 * The front-page template file
 *
 * @package Sensei S2
 * @version 2.6.0
 */

 if ( ! defined( 'ABSPATH' ) ) { 
  exit; // Exit if accessed directly. 
}

get_header(); ?>

<main role="main" id="main-content">
  <div class="main" style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(<?php header_image(); ?>);" role="img" aria-label="Background image with overlay">
    <div class="content">
      <div class="main-content center fade">
        <h1><?php bloginfo('name'); ?></h1>
        <p><?php bloginfo('description'); ?></p>
        <?php
        global $wp_customize;
        $senseis2_cta_title = esc_attr( get_theme_mod( 'senseis2__home__cta__title', esc_html__( 'Call To Action', 'sensei-s2') ) );
        $senseis2_cta_link = esc_attr( get_theme_mod( 'senseis2__home__cta__link', esc_html__( '#', 'sensei-s2') ) );
      ?>
      <!-- Call to Action -->
      <a href="<?php if ( !empty ( $senseis2_cta_link ) ) : echo esc_html( $senseis2_cta_link ); endif; ?>" tabindex="0"><?php if ( !empty ( $senseis2_cta_title ) ) : echo  esc_html( $senseis2_cta_title ); endif; ?></a>
      </div> <!-- main content -->
    </div> <!-- content -->
  </div> <!-- main -->
</main>

<?php if (!is_home() && is_front_page() ) : ?>
  <section>
    <div class="homepage-inner" style="padding-top: 70px;">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <?php the_content(); ?>
      <?php endwhile; ?>
      <?php endif; ?>
    </div> <!-- fade -->
  </section>
  <article class="fluid">
    <?php get_template_part('template-parts/main'); ?>
  </article>
<?php endif; ?>

<?php if (is_home() ) : ?>
  <div class="content wrapper">
    <div class="canvas"></div>
    <div class="square"></div>
  </div> <!-- content -->

  <article class="spacer">
    <?php get_template_part('template-parts/default'); ?>
  </article>
<?php endif; ?>

<?php get_footer();
