<?php
/**
 * The sidebar containing the main widget area
 *
 * @package Sensei S2
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) { 
  exit; // Exit if accessed directly. 
}

?>

<aside>
  <?php dynamic_sidebar( 'primary' ); ?>
</aside>
